package controller;

import model.Cirugia;
import model.Intervencion;
import model.Medico;
import model.Quirofano;

import java.math.BigDecimal;
import java.util.*;

public class Clinica {

    private  String nombre;

    private List<Medico> listaMedicos;
    private List<Quirofano> listaQuirofanos;
    private Random aleatorio = new Random(System.currentTimeMillis());
    private List<Intervencion> listaIntervenciones;

    public Clinica(String nombre) {
        this.nombre = nombre;
        listaMedicos = new ArrayList<>();
        listaQuirofanos = new ArrayList<>();
        listaIntervenciones = new ArrayList<>();
    }

    public void add(Medico m) {
        listaMedicos.add(m);
    }

	public void add(Quirofano q) {
        listaQuirofanos.add(q);
    }

    public void add(Intervencion i) {
    	listaIntervenciones.add(i);
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Medico> getListaMedicos() {
        return listaMedicos;
    }

    public List<Quirofano> getListaQuirofanos() {
        return listaQuirofanos;
    }

    public List<Intervencion> getListaIntervenciones() {
		return listaIntervenciones;
	}

	public void setListaIntervenciones(List<Intervencion> listaIntervenciones) {
		this.listaIntervenciones = listaIntervenciones;
	}

	public void setListaMedicos(List<Medico> listaMedicos) {
		this.listaMedicos = listaMedicos;
	}

	public void setListaQuirofanos(List<Quirofano> listaQuirofanos) {
		this.listaQuirofanos = listaQuirofanos;
	}

    public Quirofano getQuirofanoRandom() {
        if (listaQuirofanos.isEmpty())
            return null;
        else {
        // Producir nuevo int aleatorio entre 0 y listaQuirofanos.size()
            int posAleatoria = aleatorio.nextInt(listaQuirofanos.size());
            return listaQuirofanos.get(posAleatoria);
        }
    }

    public List<Medico> getMedicosRandom(int cantidad) {

 
        if (listaMedicos.isEmpty())
            return null;
        else {
            HashSet<Medico> setMedicos = new HashSet<Medico>();
            for (int i = 1; i <= cantidad; i++) {
                int posAleatoria = aleatorio.nextInt(listaMedicos.size());
                setMedicos.add(listaMedicos.get(posAleatoria));
            }
            return setMedicos.stream().toList();
        }
    }

    @Override
    public String toString() {
        return "Clinica " + nombre;
    }
    
    public String listarIntervenciones() {
    	Collections.sort(listaIntervenciones, new Comparator<Intervencion>() {

			@Override
			public int compare(Intervencion o1, Intervencion o2) {
				if(o1 instanceof Cirugia)
					return -1;
				else return 1;
			}
   
    	});
    	StringBuilder sb = new StringBuilder();
    	sb.append(toString() + " - Listado de Intervenciones de Quirofanos\n=====================================================================\n");
    	listaIntervenciones.forEach(a-> sb.append(a.toString()+"--------------------------------------------------------------------------------------\n"));
    	sb.append(" \nCantidad de Intervenciones: "+listaIntervenciones.size());
    	Intervencion intervencion = getIntervencionMasCara(listaIntervenciones);
    	sb.append("\n\nIntervencion mas Cara: " + intervencion);
    	return sb.toString();
    }

    
	private Intervencion getIntervencionMasCara(List<Intervencion> listaIntervenciones) {
		double max = 0;
		Intervencion maxIntervencion = null;
			for(Intervencion intervencion : listaIntervenciones) {
				if(intervencion.getFacturacion() > max) {
					maxIntervencion = intervencion;
					max = intervencion.getFacturacion();
				}
			}		
		return maxIntervencion;
	}
}
