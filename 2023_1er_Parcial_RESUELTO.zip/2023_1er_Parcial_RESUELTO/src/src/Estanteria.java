package src;

public class Estanteria extends Compartimento{

	private static final double COSTO_DIARIO_ESTANTERIA = 100;
	private double cantidadNiveles;

	public Estanteria(String idCompartimento, Area area, String descripcion, int capacidad, int cantOcupada, int cantNiveles) {
		super(idCompartimento, area, descripcion, capacidad, cantOcupada);
		this.cantidadNiveles = cantNiveles;
	}

	public double getCosto() {
		return super.getCosto() + COSTO_DIARIO_ESTANTERIA + getCantidadNiveles() * getCostoDiarioNivel(); 
	}

	@Override
	public String toString() {
		return super.toString() + "cant.niveles: "+cantidadNiveles + "   Costo:"+getCosto() +"\n";
	}

	public double getCantidadNiveles() {
		return cantidadNiveles;
	}

	public void setCantidadNiveles(double cantidadNiveles) {
		this.cantidadNiveles = cantidadNiveles;
	}
	
}
