package src;

public class RunEmpresa {


public static void main(String[] args) {
	Empresa empresa = RunEmpresa.creaEmpresa();
	System.out.println(empresa.showInformacionCostosDiarios());
}

private void agregaCantidadesRandom(Area area) {
	
}

public static Empresa creaEmpresa() {
	Empresa empresa = new Empresa("Acovacha y despacha S.a");
	Area area1 = new Area("S03", "Sector 3");
	area1.getCompartimentos().add(new Estanteria("E01", area1, "Aceites", 1000, 245, 4));
	area1.getCompartimentos().add(new Estanteria("E02", area1, "limpieza", 4000, 13, 2));
	area1.getCompartimentos().add(new Estanteria("E03", area1, "Vinoteca", 3000, 1671, 1));
	empresa.getAreas().add(area1);

	Area area2 = new Area("F01", "Frigorifico");
	area2.getCompartimentos().add(new Refrigerado("C01", area2, "Camara carniceria", 5000, 3977, 0, 10));
	area2.getCompartimentos().add(new Refrigerado("C02", area2, "camara de lacteos", 3000, 1709, 6, 30));
	area2.getCompartimentos().add(new Refrigerado("E01", area2, "Camara de congelados", 3000, 2326, -5, 20));
	area2.getCompartimentos().add(new Estanteria("E07", area2, "Estante de quesos", 1000, 567, 2));
	empresa.getAreas().add(area2);

	if(area2.getCompartimentos().get(2).retirar(99999))
		System.out.println("nashe");
	else System.out.println("biennnnnn");
	System.out.println(area2.getCompartimentos().get(2).getCantOcupada());
	return empresa;
}

}
