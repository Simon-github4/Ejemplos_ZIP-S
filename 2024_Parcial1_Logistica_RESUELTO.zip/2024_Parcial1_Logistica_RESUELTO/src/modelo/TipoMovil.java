package modelo;

public enum TipoMovil {
	BICICLETA, CAMION, REFRIGERADO;
}
