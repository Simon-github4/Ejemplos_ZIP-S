package modelo;

public enum Zonas {
	NORTE, SUR, ESTE, OESTE;
}
