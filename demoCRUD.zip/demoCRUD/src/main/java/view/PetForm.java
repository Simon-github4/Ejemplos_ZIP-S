package view;

import DAO.PetDAO;
import DAO.PetTypeDAO;
import model.Pet;
import model.PetType;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import view.ViewUtils;

public class PetForm extends JFrame {

    private JTextField nameField, notesField, petIdField;

    private JSpinner yearofbirthField;
    private JComboBox<PetType> pettypeComboBox;
    private JButton confirmButton, deleteButton, cancelButton;

    private JLabel messageLabel;
    private JTable petTable;
    private DefaultTableModel tableModel;
    private PetDAO petDAO;
    private PetTypeDAO petTypeDAO;

    public PetForm(PetDAO petDAO, PetTypeDAO petTypeDAO) {
        this.petDAO = petDAO;
        this.petTypeDAO = petTypeDAO;

        setTitle("Gestión de Mascotas");
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.Y_AXIS));

        JLabel petIdLabel = new JLabel("ID de Mascota: ", JLabel.RIGHT);
        petIdField = new JTextField(20);
        JLabel nameLabel = new JLabel("Nombre: ", JLabel.RIGHT);
        nameField = new JTextField(20);
        JLabel notesLabel = new JLabel("Notas: ", JLabel.RIGHT);
        notesField = new JTextField(20);
        JLabel yearofbirthLabel = new JLabel("Año de Nacimiento: ", JLabel.RIGHT);
        yearofbirthField = new JSpinner();

        JLabel pettypeIdLabel = new JLabel("Tipo de Mascota: ", JLabel.RIGHT);
        // Configuración del JComboBox para el tipo de mascota
        pettypeComboBox = new JComboBox<>();
        loadPetTypes();

        confirmButton = new JButton("Confirmar");
        ViewUtils.setIconToButton(confirmButton, "/imgs/confirm.png", 16, 16);

        deleteButton = new JButton("Eliminar");
        ViewUtils.setIconToButton(deleteButton, "/imgs/delete.png", 16, 16);


        cancelButton = new JButton("Limpiar");
        ViewUtils.setIconToButton(cancelButton, "/imgs/cancel.png", 16, 16);

        JPanel horizontalPanel = new JPanel(new GridLayout());
        horizontalPanel.add(petIdLabel);
        horizontalPanel.add(petIdField);
        inputPanel.add(horizontalPanel);

        horizontalPanel = new JPanel(new GridLayout());
        horizontalPanel.add(nameLabel);
        horizontalPanel.add(nameField);
        inputPanel.add(horizontalPanel);

        horizontalPanel = new JPanel(new GridLayout());
        horizontalPanel.add(yearofbirthLabel);
        horizontalPanel.add(yearofbirthField);
        inputPanel.add(horizontalPanel);

        horizontalPanel = new JPanel(new GridLayout());
        horizontalPanel.add(notesLabel);
        horizontalPanel.add(notesField);
        inputPanel.add(horizontalPanel);

        horizontalPanel = new JPanel(new GridLayout());
        horizontalPanel.add(pettypeIdLabel);
        horizontalPanel.add(pettypeComboBox);
        inputPanel.add(horizontalPanel);


        horizontalPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        horizontalPanel.add(confirmButton);
        horizontalPanel.add(deleteButton);
        horizontalPanel.add(cancelButton);
        inputPanel.add(horizontalPanel);

        JPanel tablePanel = new JPanel(new BorderLayout());
        tableModel = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Hacer que todas las celdas sean no editables
            }
        };
        petTable = new JTable(tableModel);

// Definir las columnas de la tabla
        tableModel.addColumn("ID de Mascota");
        tableModel.addColumn("Nombre");
        tableModel.addColumn("Fecha Nacimiento");
        tableModel.addColumn("Notas");
        tableModel.addColumn("Tipo de mascota");
        tableModel.addColumn("Object");

// Establecer los anchos de las columnas
        petTable.getColumnModel().getColumn(0).setMinWidth(40);
        petTable.getColumnModel().getColumn(0).setPreferredWidth(40);
        petTable.getColumnModel().getColumn(1).setMinWidth(40);
        petTable.getColumnModel().getColumn(1).setPreferredWidth(40);
        petTable.getColumnModel().getColumn(2).setMinWidth(60);
        petTable.getColumnModel().getColumn(2).setPreferredWidth(60);
        petTable.getColumnModel().getColumn(3).setMinWidth(260);
        petTable.getColumnModel().getColumn(3).setPreferredWidth(300);
        petTable.getColumnModel().getColumn(4).setMinWidth(80);
        petTable.getColumnModel().getColumn(4).setPreferredWidth(80);

// Ocultar la columna del objeto Pet
        petTable.getColumnModel().getColumn(5).setMinWidth(0);
        petTable.getColumnModel().getColumn(5).setMaxWidth(0);
        petTable.getColumnModel().getColumn(5).setPreferredWidth(0);

        JScrollPane scrollPane = new JScrollPane(petTable);
        tablePanel.add(scrollPane, BorderLayout.CENTER);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(inputPanel, BorderLayout.NORTH);
        mainPanel.add(tablePanel, BorderLayout.CENTER);
        messageLabel = new JLabel(" ", SwingConstants.CENTER);
        messageLabel.setForeground(Color.WHITE);
        messageLabel.setFont(new Font("Arial", Font.BOLD, 16));
        messageLabel.setBackground(Color.RED);
        messageLabel.setOpaque(false);
        mainPanel.add(messageLabel, BorderLayout.SOUTH);
        mainPanel.setPreferredSize(new Dimension(800,600));
        getContentPane().add(mainPanel);

        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateFields()) {
                    int selectedRow = petTable.getSelectedRow();
                    if (selectedRow == -1)
                        insertPet();
                    else
                        updatePet();
                }
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deletePet();
            }
        });

        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });

        // Cargar datos iniciales de la tabla
        loadPets();

        // Configurar selección de fila en la tabla
        petTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = petTable.getSelectedRow();
                    if (selectedRow != -1) {
                        // Mostrar datos de la fila seleccionada en los campos de texto
                        long petId = (long) tableModel.getValueAt(selectedRow, 0);
                        String name = (String) tableModel.getValueAt(selectedRow, 1);
                        int yearofbirth = (int) tableModel.getValueAt(selectedRow, 2);
                        String notes = (String) tableModel.getValueAt(selectedRow, 3);
                        PetType petType =((Pet)(tableModel.getValueAt(selectedRow, 5))).getPettype();

                        petIdField.setText(String.valueOf(petId));
                        nameField.setText(name);
                        yearofbirthField.setValue(yearofbirth);
                        notesField.setText(notes);
                        pettypeComboBox.setSelectedItem(petType);
                    }
                }
            }
        });
        clearFields();
        pack();
        setLocationRelativeTo(null); // Centrar ventana
        setVisible(true);
    }

    private void loadPets() {
        try {
            // Limpiar tabla antes de cargar nuevos datos
            tableModel.setRowCount(0);

            // Obtener lista de mascotas desde la base de datos
            List<Pet> pets = petDAO.getAllPets();

            // Llenar la tabla con los datos obtenidos
            for (Pet pet : pets) {
                Object[] row = {pet.getPet(), pet.getName(), pet.getYearofbirth(), pet.getNotes(), pet.getPettype().getDescription(), pet};
                tableModel.addRow(row);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al cargar mascotas: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadPetTypes() {
        try {
            List<PetType> petTypes = petTypeDAO.getAllPetTypes();
            for (PetType petType : petTypes) {
                pettypeComboBox.addItem(petType);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al cargar tipos de mascotas: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    public boolean validateFields() {
        boolean response = false;
        if (nameField.getText().isBlank()) {
            setMessage("El nombre de la mascota es un campo obligatorio");
            nameField.requestFocus();
        }
        else if ((int)yearofbirthField.getValue()<2000) {
            setMessage("El año de nacimiento no puede ser anterior a 2000");
            yearofbirthField.requestFocus();
        }
        else
            response = true;
        return response;
    }

    private void insertPet() {
        String name = nameField.getText();
        int yearOfBirth = (int)yearofbirthField.getValue();
        String notes = notesField.getText();
        PetType petType = (PetType) pettypeComboBox.getSelectedItem();
        try {
            petDAO.insertPet(name, yearOfBirth, notes, petType.getPettype());
            JOptionPane.showMessageDialog(this, "Mascota insertada correctamente");
            clearFields();
            loadPets(); // Recargar la tabla después de la inserción
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al insertar mascota: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updatePet() {
        int selectedRow = petTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Por favor selecciona una mascota para actualizar",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        long petId = (long) tableModel.getValueAt(selectedRow, 0); // ID de la mascota desde la tabla
        String name = nameField.getText();
        int yearofbirth = (int)yearofbirthField.getValue();
        String notes = notesField.getText();
        PetType petType = (PetType) pettypeComboBox.getSelectedItem();

        try {
            petDAO.updatePet(petId, name, yearofbirth, notes, petType.getPettype());
            JOptionPane.showMessageDialog(this, "Mascota actualizada correctamente");
            clearFields();
            loadPets(); // Recargar la tabla después de la actualización
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al actualizar mascota: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void setMessage(String message) {
        messageLabel.setText(message);
        messageLabel.setOpaque(true);
    }

    private void deletePet() {
        int selectedRow = petTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Por favor selecciona una mascota para eliminar",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "¿Estás seguro de eliminar esta mascota?",
                "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            long petId = (long) tableModel.getValueAt(selectedRow, 0); // ID de la mascota desde la tabla

            try {
                petDAO.deletePet(petId);
                JOptionPane.showMessageDialog(this, "Mascota eliminada correctamente");
                clearFields();
                loadPets(); // Recargar la tabla después de la eliminación
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error al eliminar mascota: " + ex.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void clearFields() {
        petIdField.setText("");
        nameField.setText("");
        yearofbirthField.setValue(0);
        notesField.setText("");
        pettypeComboBox.setSelectedIndex(0);
        petTable.clearSelection();
        petIdField.setEnabled(false);
        nameField.requestFocus();
        messageLabel.setText(" ");
        messageLabel.setOpaque(false);
    }
}
