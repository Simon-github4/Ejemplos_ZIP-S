package src;

import java.util.ArrayList;
import java.util.List;

public class Empresa {

private String nombre;
private List<Area> areas;

public Empresa(String nombre) {
	this.areas = new ArrayList<>(); 
	this.nombre = nombre;
}

public String showInformacionCostosDiarios() {
	StringBuilder sb = new StringBuilder();
	areas.forEach(a->{sb.append(a);
					a.getCompartimentos().forEach(b-> sb.append(b));
					});
	String total = String.valueOf(getCostoTotal(areas));
	sb.append("Costo total diario: "+total);
	Compartimento max = (getMaxCosto(areas));
	sb.append(" \nCompartimento mayor costo:"); 
	sb.append(max.getDescripcion() +": " + max.getCosto());
	return sb.toString();
}

private Compartimento getMaxCosto(List<Area> area) {
	Compartimento max= null;
	double costoMax = 0;
	for(Area a : area) {
		for(Compartimento c : a.getCompartimentos())
			if(c.getCosto() > costoMax) {
				max = c;
				costoMax = c.getCosto();
			}
	}
	//area.forEach(a->a.getCompartimentos().forEach(b-> total+= b.getCosto()));
	return max;
}

private double getCostoTotal(List<Area> area) {
	double total=0;
	for(Area a : area) {
		for(Compartimento c : a.getCompartimentos())
			total += c.getCosto();
	}
	//area.forEach(a->a.getCompartimentos().forEach(b-> total+= b.getCosto()));
	return total;
}

public String getNombre() {
	return nombre;
}


public void setNombre(String nombre) {
	this.nombre = nombre;
}


public List<Area> getAreas() {
	return areas;
}


public void setAreas(List<Area> areas) {
	this.areas = areas;
}


}
