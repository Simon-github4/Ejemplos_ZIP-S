package src;

import java.util.Objects;

public class Colaboracion implements Comparable{

private String descripcion;
private double costoMesXVoluntario;

public Colaboracion(String descripcion, double costoMesXVoluntario) {
	super();
	this.descripcion = descripcion;
	this.costoMesXVoluntario = costoMesXVoluntario;
}

@Override
public String toString() {
	return "\n" +"\t \t \t \t \t \t \t "+ descripcion + " \t -" + costoMesXVoluntario  ;
}

public String getDescripcion() {
	return descripcion;
}

public void setDescripcion(String descripcion) {
	this.descripcion = descripcion;
}

public double getCostoMesXVoluntario() {
	return costoMesXVoluntario;
}

public void setCostoMesXVoluntario(double costoMesXVoluntario) {
	this.costoMesXVoluntario = costoMesXVoluntario;
}

@Override
public int hashCode() {
	return Objects.hash(costoMesXVoluntario, descripcion);
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Colaboracion other = (Colaboracion) obj;
	return Double.doubleToLongBits(costoMesXVoluntario) == Double.doubleToLongBits(other.costoMesXVoluntario)
			&& Objects.equals(descripcion, other.descripcion);
}

@Override
public int compareTo(Object o) {
	return this.getDescripcion().compareTo(((Colaboracion) o).getDescripcion());
}


}
