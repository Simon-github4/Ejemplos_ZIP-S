package modelo;

import java.time.LocalDate;
import java.util.List;

public class HojaRutaCamion extends HojaRuta {

private boolean requiereAyudante;

public HojaRutaCamion(Movil movil) {
	super(movil);
}

	@Override
	public boolean agregar(Entrega entrega) {
		boolean rta = super.agregar(entrega);

		if (entrega.getPeso() > 20)
			requiereAyudante = true;

		if (rta == true)
			getEntregas().add(entrega);

		return rta;
	}

	@Override
	public double getCosto() {
		double costo = super.getCosto();
		if (isRequiereAyudante() == true)
			costo += 1000;
		return costo;
	}

	@Override
	public String toString() {
		return super.toString() + "  Ayudante:" + isRequiereAyudante() + "\n" + getEntregas().toString() + "\n";
	}

	public boolean isRequiereAyudante() {
		return requiereAyudante;
	}

	public void setRequiereAyudante(boolean requiereAyudante) {
		this.requiereAyudante = requiereAyudante;
	}

}
