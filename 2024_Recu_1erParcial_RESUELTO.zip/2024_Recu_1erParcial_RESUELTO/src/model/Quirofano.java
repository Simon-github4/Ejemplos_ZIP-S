package model;

import java.math.BigDecimal;
import java.util.Objects;

public class Quirofano {
    private int numeroQuirofano;
    private BigDecimal valorBase;

    public Quirofano(int numeroQuirofano, BigDecimal valorBase) {
        this.numeroQuirofano = numeroQuirofano;
        this.valorBase = valorBase;
    }

    public int getNumeroQuirofano() {
        return numeroQuirofano;
    }

    public void setNumeroQuirofano(int numeroQuirofano) {
        this.numeroQuirofano = numeroQuirofano;
    }

    public BigDecimal getValorBase() {
        return valorBase;
    }

    public void setValorBase(BigDecimal valorBase) {
        this.valorBase = valorBase;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Quirofano quirofano = (Quirofano) o;
        return numeroQuirofano == quirofano.numeroQuirofano && Objects.equals(valorBase, quirofano.valorBase);
    }

    @Override
    public int hashCode() {
        return Objects.hash(numeroQuirofano, valorBase);
    }
}
