package src;

import java.util.ArrayList;
import java.util.List;

public class Area {

private String idArea;
private String descripcion;
private List<Compartimento> compartimentos;

public Area(String idArea, String descripcion) {
	super();
	this.idArea = idArea;
	this.descripcion = descripcion;
	this.compartimentos = new ArrayList<>();;
}


@Override
public String toString() {
	
	return idArea + " - " + descripcion + "\n" ;
}


public String getIdArea() {
	return idArea;
}
public void setIdArea(String idArea) {
	this.idArea = idArea;
}
public String getDescripcion() {
	return descripcion;
}
public void setDescripcion(String descripcion) {
	this.descripcion = descripcion;
}
public List<Compartimento> getCompartimentos() {
	return compartimentos;
}
public void setCompartimentos(List<Compartimento> compartimentos) {
	this.compartimentos = compartimentos;
}


}
