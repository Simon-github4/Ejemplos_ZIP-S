package src;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class ONG {

private String nombre;
private List<Colaborador> colaboradores= new ArrayList<>();
private List<Colaboracion> tiposColaboracion= new ArrayList<>();
private Map<Colaboracion, Double> gastos= new TreeMap<Colaboracion, Double>();

public ONG(String string) {
	this.nombre = string;
}

public void agregar(Colaborador c) {
	colaboradores.add(c);
}

public void agregar(Colaboracion c) {
	tiposColaboracion.add(c);
	gastos.put(c, new Double( 0));
}

public String mostrarInfo() {
	Collections.sort(getColaboradores());
	StringBuilder colaboradoress = new StringBuilder();
	getColaboradores().forEach(a -> colaboradoress.append(a.toString()));

	double total = 0;
	double aportes = 0;
	double actual;

	for (Colaborador c : getColaboradores()) {
		if (c instanceof Voluntario) {
			actual = 0;
			for (Colaboracion colab : ((Voluntario) c).getColaboraciones()) {
				System.out.println(gastos.get(colab));
				actual = gastos.get(colab);
				gastos.replace(colab, (actual - (double) colab.getCostoMesXVoluntario()));
				total -= colab.getCostoMesXVoluntario();
			}
		} else
			aportes += ((Aportante) c).getAporteMensual();
	}
	total += aportes;

	String info = "ONG " + getNombre() + " - Lista de Colaboradores \n"
			+ "----------------------------------------------------------------------------------------------------------\n"
			+ "nombre \t ano \t tipo colaborador \t Aporte \t colaboraciones\n"
			+ "===========================================================================================================\n"
			+ colaboradoress
			+ "----------------------------------------------------------------------------------------------------------\n"
			+ "la cantidad de colaboradores es de: " + getColaboradores().size()
			+ "\nDetalles de ingreso y egreso:\nAportes: \t " + aportes + "\n" + getEgresosXTarea()
			+ ((total < 0) ? "El presupuesto es deficitario:" : "El presupuesto es superavitario:") + total;
	return info;
}


private String getEgresosXTarea() {
	StringBuilder sb = new StringBuilder();
	//Iterator<Colaboracion, Double> it = gastos.keySet().iterator();
	gastos.forEach((tipo, gasto) -> sb.append(tipo.getDescripcion()+" \t "+gasto+"\n"));
	return sb.toString();
}

public String getNombre() {
	return nombre;
}

public void setNombre(String nombre) {
	this.nombre = nombre;
}

public List<Colaborador> getColaboradores() {
	return colaboradores;
}

public void setColaboradores(List<Colaborador> colaboradores) {
	this.colaboradores = colaboradores;
}

public List<Colaboracion> getTiposColaboracion() {
	return tiposColaboracion;
}

public void setTiposColaboracion(List<Colaboracion> tiposColaboracion) {
	this.tiposColaboracion = tiposColaboracion;
}

public Map<Colaboracion, Double> getGastos() {
	return gastos;
}

public void setGastos(Map<Colaboracion, Double> gastos) {
	this.gastos = gastos;
}


}
