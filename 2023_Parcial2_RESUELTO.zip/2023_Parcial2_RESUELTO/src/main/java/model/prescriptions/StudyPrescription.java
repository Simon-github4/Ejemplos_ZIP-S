package model.prescriptions;

import java.util.Date;

import model.Patient;

public class StudyPrescription extends Prescription{

private String requiredStudy;
private String diagnosis;

public StudyPrescription(int prescription, Patient patient, Date date, String professional, String requiredStudy, String diagnosis) {
		super(prescription, patient, date, professional);
		this.requiredStudy = requiredStudy;
		this.diagnosis = diagnosis;
}

public String getRequiredStudy() {
	return requiredStudy;
}

public void setRequiredStudy(String requiredStudy) {
	this.requiredStudy = requiredStudy;
}

public String getDiagnosis() {
	return diagnosis;
}

public void setDiagnosis(String diagnosis) {
	this.diagnosis = diagnosis;
}

@Override
public String toString() {
	return getDate()+"-"+ getProfessional() +"\t"+requiredStudy +"\tDiagnostico: "+ diagnosis+"\t"+getPrice();
}

@Override
public float getPrice() {
	return 1000;
}





}
