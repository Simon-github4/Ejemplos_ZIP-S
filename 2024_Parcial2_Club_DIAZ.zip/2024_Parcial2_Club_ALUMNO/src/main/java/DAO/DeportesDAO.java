package DAO;

import model.Deporte;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DeportesDAO {

    public void insertarDeporte(String descripcion, BigDecimal valor) throws SQLException {
        //TO DO: Insertar nuevo deporte en la tabla deportes, aquí
    	String consulta = "INSERT INTO deportes ( descripcion, valor) VALUES(?, ?)";
		
		Connection conexion = DBConnection.getConnection();
		PreparedStatement pstmt = conexion.prepareStatement(consulta);
	
        pstmt.setString(1, descripcion);
        pstmt.setBigDecimal(2, valor);
        pstmt.executeUpdate();   
    }

    public void actualizarDeporte(long iddeporte, String descripcion, BigDecimal valor) throws SQLException {
        //TO DO: Actualizar registro en la tabla deportes, aquí
    	String consulta = "UPDATE deportes SET descripcion = ?, valor = ? WHERE iddeporte = ?";
		Connection conexion = DBConnection.getConnection();
		PreparedStatement pstmt = conexion.prepareStatement(consulta);
		pstmt.setString(1, descripcion);
		pstmt.setBigDecimal(2, valor);
		pstmt.setLong(3, iddeporte);
		pstmt.executeUpdate();
    }

    public void borrarDeporte(long iddeporte) throws SQLException {
        //TO DO: Eliminar registro en la tabla deportes, aquí
    	String consulta = "DELETE FROM deportes WHERE iddeporte = ?";
		Connection conexion = DBConnection.getConnection();
		PreparedStatement pstmt = conexion.prepareStatement(consulta);
		pstmt.setLong(1,iddeporte);
		pstmt.executeUpdate();
    }

    public List<Deporte> getListaDeportes() throws SQLException {
        List<Deporte> listaDeportes = new ArrayList<>();

        //TO DO: Recuperar registros de la tabla deportes y crearlos en la lista, aquí
        String sql = "SELECT iddeporte, descripcion, valor FROM deportes";
        //long idSocio = -1;
        try (Connection conn = DBConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
        	ResultSet rs = pstmt.executeQuery();
        	while(rs.next()) {
        		listaDeportes.add(new Deporte(rs.getLong("iddeporte"), rs.getString("descripcion"), rs.getBigDecimal("valor") ));
        	}	
         }
                 
        return listaDeportes;
    }


}

