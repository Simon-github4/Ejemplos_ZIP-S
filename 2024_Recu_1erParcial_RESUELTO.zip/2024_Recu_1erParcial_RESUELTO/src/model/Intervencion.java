package model;

import java.util.List;

import view.ViewUtils;

public abstract class Intervencion {

private static final double PORC_INCREMENTO_URGENCIA = 20;

private String paciente;
private int duracion;
private boolean urgente;
private Quirofano quirofano;
private List<Medico> medicos;

public Intervencion(String paciente, int duracion, boolean urgente, Quirofano quirofano, List<Medico> medicos) {
	super();
	this.paciente = paciente;
	this.duracion = duracion;
	this.urgente = urgente;
	this.quirofano = quirofano;
	this.medicos = medicos;
}

public double getFacturacion(){
	double valorBase = getQuirofano().getValorBase().doubleValue();
	for(Medico medico : medicos) {
		valorBase += medico.getValorHora().doubleValue() * Math.ceilDiv(getDuracion(), 60);
	}
	if(isUrgente())
		valorBase += (valorBase*(getPorcIncrementoUrgencia())/100);
	
	return valorBase;
}


@Override
public String toString() {
	StringBuilder sb = new StringBuilder();
	sb.append("Paciente: " + getPaciente() + "\t - " + getClass().getSimpleName() + "  Quirofano: " + getQuirofano().getNumeroQuirofano() + " \t Duracion: "
			  + getDuracion() + "min. \n\tUrgente:" + (isUrgente()?"Si":"No"));
	sb.append("\n\tMedicos:" );
	getMedicos().forEach(a-> sb.append(a.toString()+"; "));
	sb.append("\t Valor: " + (getFacturacion()) + "\n"); //ViewUtils.formatearMoneda((float)getFacturacion())
	
	return sb.toString();
}

public static double getPorcIncrementoUrgencia() {
	return PORC_INCREMENTO_URGENCIA;
}

public String getPaciente() {
	return paciente;
}
public void setPaciente(String paciente) {
	this.paciente = paciente;
}
public int getDuracion() {
	return duracion;
}
public void setDuracion(int duracion) {
	this.duracion = duracion;
}
public boolean isUrgente() {
	return urgente;
}
public void setUrgente(boolean urgente) {
	this.urgente = urgente;
}
public Quirofano getQuirofano() {
	return quirofano;
}
public void setQuirofano(Quirofano quirofano) {
	this.quirofano = quirofano;
}
public List<Medico> getMedicos() {
	return medicos;
}
public void setMedicos(List<Medico> medicos) {
	this.medicos = medicos;
}



}
