package DAO;

import model.PetType;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PetTypeDAO {

    public void insertPetType(String description) throws SQLException {
        String sql = "INSERT INTO pettype (pettype, description) VALUES (nextval('pettype_pettype_seq'), ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, description);
            pstmt.executeUpdate();
        }
    }

    public void updatePetType(long pettypeId, String newDescription) throws SQLException {
        String sql = "UPDATE pettype SET description = ? WHERE pettype = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, newDescription);
            pstmt.setLong(2, pettypeId);
            pstmt.executeUpdate();
        }
    }

    public void deletePetType(long pettypeId) throws SQLException {
        String sql = "DELETE FROM pettype WHERE pettype = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setLong(1, pettypeId);
            pstmt.executeUpdate();
        }
    }

    public void displayAllPetTypes() throws SQLException {
        String sql = "SELECT pettype, description FROM pettype";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                long pettypeId = rs.getLong("pettype");
                String description = rs.getString("description");
                System.out.println("Pet Type ID: " + pettypeId + ", Description: " + description);
            }
        }
    }

    public List<PetType> getAllPetTypes() throws SQLException {
        String sql = "SELECT pettype, description FROM pettype order by description";
        List<PetType> petTypes = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                long pettypeId = rs.getLong("pettype");
                String description = rs.getString("description");
                PetType petType = new PetType(pettypeId, description);
                petTypes.add(petType);
            }
        }
        return petTypes;
    }

    public PetType getPetTypeById(long id) throws SQLException {
        String sql = "SELECT pettype, description FROM pettype WHERE pettype = ?";
        PetType petType = null;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setLong(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    long pettypeId = rs.getLong("pettype");
                    String description = rs.getString("description");
                    petType = new PetType(pettypeId, description);
                }
            }
        }

        return petType;
    }

}

