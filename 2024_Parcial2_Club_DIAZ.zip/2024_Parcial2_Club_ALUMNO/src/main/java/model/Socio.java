package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Socio {

private long idsocio;
private String nombre;
private char genero;
private List<Deporte> deportes;

public Socio(long idsocio, String nombre, char genero) {
	super();
	this.idsocio = idsocio;
	this.nombre = nombre;
	this.genero = genero;
	this.deportes = new ArrayList<Deporte>();
}

public float getPrecioCuota(){
	float cuota=0;
	for(Deporte deporte : getDeportes()) {
		cuota+= deporte.getValor().floatValue();
	}
	if(getDeportes().size() >= 2)
		cuota *= 0.8;
	return cuota;
}

public String isVitalicio() {
	// TODO Auto-generated method stub
	return "No";
}

public long getIdSocio() {
	return idsocio;
}

public void setIdsocio(long idsocio) {
	this.idsocio = idsocio;
}

public String getNombre() {
	return nombre;
}

public void setNombre(String nombre) {
	this.nombre = nombre;
}

public char getGenero() {
	return genero;
}

public void setGenero(char genero) {
	this.genero = genero;
}

public List<Deporte> getDeportes() {
	return deportes;
}

public void setDeportes(List<Deporte> deportes) {
	this.deportes = deportes;
}

@Override
public int hashCode() {
	return Objects.hash(deportes, genero, idsocio, nombre);
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Socio other = (Socio) obj;
	return Objects.equals(deportes, other.deportes) && genero == other.genero && idsocio == other.idsocio
			&& Objects.equals(nombre, other.nombre);
}

@Override
public String toString() {
	String genero;
	if(getGenero()== 'M')
		genero = "Masculino";
	else genero = "Femenino";
		
	return  getIdSocio() + " - " + getNombre() + "\t" +genero +"\t"+ "Comun" 
			+ "\n\t\tDeportes:\t" + getDeportes()	
			+ "\n\t\tValor cuota: $"+getPrecioCuota()+"\n\n";
	}










}
