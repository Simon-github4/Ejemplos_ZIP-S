package src;

import java.util.ArrayList;
import java.util.List;

public class Voluntario extends Colaborador{

private List<Colaboracion> colaboraciones;

public Voluntario(String nombre, int anioIngreso) {
		super(nombre, anioIngreso);
		this.colaboraciones= new ArrayList<>();
}

public void agregar(Colaboracion c) {
	colaboraciones.add(c);
}

	
	
public List<Colaboracion> getColaboraciones() {
	return colaboraciones;
}

public void setColaboraciones(List<Colaboracion> colaboraciones) {
	this.colaboraciones = colaboraciones;
}

@Override
public String toString() {
	StringBuilder colaboradoress = new StringBuilder();
	getColaboraciones().forEach(a-> colaboradoress.append(a.toString()));
	return super.toString() + " \t Voluntario" + colaboradoress +"\n";
}

}
