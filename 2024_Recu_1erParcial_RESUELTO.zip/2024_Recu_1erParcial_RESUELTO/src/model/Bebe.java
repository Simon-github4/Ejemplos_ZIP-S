package model;

public class Bebe {
    private String nombre;
    private double peso;
    private char genero;

    public Bebe(String nombre, double peso, char genero) {
        this.nombre = nombre;
        this.peso = peso;
        this.genero = genero;
    }

    
    @Override
	public String toString() {
		return "Nombre: " + nombre + "   Peso: " + peso + "  Genero: " + ((genero == 'H')?"Masc." : "Fem.");
	}



	public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public char getGenero() {
        return genero;
    }

    public void setGenero(char genero) {
        this.genero = genero;
    }


}
