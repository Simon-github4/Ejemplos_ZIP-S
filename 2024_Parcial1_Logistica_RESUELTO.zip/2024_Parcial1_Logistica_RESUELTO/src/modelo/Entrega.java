package modelo;

import java.time.LocalDate;

public class Entrega {

private LocalDate fechaRecepcion;
private String idEntrega;
private String nombreDestinatario;
private String domicilio;
private float distancia;
private float peso;
private float temperaturaRecomendada;
private Zonas zona;

public Entrega(String idEntrega, String nombreDestinatario, String domicilio, float distancia, float peso, Zonas zona) {
	this.fechaRecepcion = LocalDate.now();
	this.idEntrega = idEntrega;
	this.nombreDestinatario = nombreDestinatario;
	this.domicilio = domicilio;
	this.distancia = distancia;
	this.peso = peso;
	this.zona = zona;
	this.temperaturaRecomendada = 99;
}

public Entrega(String idEntrega, String nombreDestinatario, String domicilio, float distancia, float peso, Zonas zona,
		float temperaturaRecomendada) {
	this.fechaRecepcion = LocalDate.now();
	this.idEntrega = idEntrega;
	this.nombreDestinatario = nombreDestinatario;
	this.domicilio = domicilio;
	this.distancia = distancia;
	this.peso = peso;
	this.temperaturaRecomendada = temperaturaRecomendada;
	this.zona = zona;
}

@Override
public String toString() {
	return idEntrega + " - " + nombreDestinatario + " - " + domicilio + "\tkm:" + distancia + "\tkg:" + peso + "\tC:"
			+ temperaturaRecomendada + "\n";
}

public LocalDate getFechaRecepcion() {
	return fechaRecepcion;
}

public void setFechaRecepcion(LocalDate fechaRecepcion) {
	this.fechaRecepcion = fechaRecepcion;
}

public String getIdEntrega() {
	return idEntrega;
}

public void setIdEntrega(String idEntrega) {
	this.idEntrega = idEntrega;
}

public String getNombreDestinatario() {
	return nombreDestinatario;
}

public void setNombreDestinatario(String nombreDestinatario) {
	this.nombreDestinatario = nombreDestinatario;
}

public String getDomicilio() {
	return domicilio;
}

public void setDomicilio(String domicilio) {
	this.domicilio = domicilio;
}

public float getDistancia() {
	return distancia;
}

public void setDistancia(float distancia) {
	this.distancia = distancia;
}

public float getPeso() {
	return peso;
}

public void setPeso(float peso) {
	this.peso = peso;
}

public float getTemperaturaRecomendada() {
	return temperaturaRecomendada;
}

public void setTemperaturaRecomendada(float temperaturaRecomendada) {
	this.temperaturaRecomendada = temperaturaRecomendada;
}

public Zonas getZona() {
	return zona;
}

public void setZona(Zonas zona) {
	this.zona = zona;
}


}
