package model;

import java.util.HashMap;
import java.util.Map;

public class SocioVitalicio extends Socio{

public SocioVitalicio(long idsocio, String nombre, char genero) {
	super(idsocio, nombre, genero);
}

@Override
public String isVitalicio() {
	// TODO Auto-generated method stub
	return "Si";
}

@Override
public float getPrecioCuota(){
	//socio con 2 o mas deportes 20 desc, vital 40 desc del total
	float cuota=0;
	for(Deporte deporte : getDeportes()) {
		cuota+= deporte.getValor().floatValue();
	}
	return cuota *= 0.6; //descuento del 40% del total
}

@Override
public String toString() {
	String genero;
	if(getGenero()== 'M')
		genero = "Masculino";
	else genero = "Femenino";
		
	return  getIdSocio() + " - " + getNombre() + "\t" +genero +"\t"+ "Vitalicio" 
			+ "\n\t\tDeportes:\t" + getDeportes()	
			+ "\n\t\tValor cuota: $"+getPrecioCuota()+"\n\n";
}


}
