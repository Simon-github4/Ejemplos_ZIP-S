package controller;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Map.Entry;

import javax.swing.text.DateFormatter;

import dataaccess.DBManager;
import model.MedicalAssurance;
import model.Medicine;
import model.Patient;
import model.prescriptions.MedicinePrescription;
import model.prescriptions.Prescription;
import model.prescriptions.StudyPrescription;

public class ClinicController {
	private DBManager dbManager;
	private HashMap<Integer, Medicine> medicines;
	private HashMap<Integer, MedicalAssurance> medicalAssurances;
	private HashMap<Integer, Patient> patients;
	private ArrayList<Prescription> prescriptions;

	public ClinicController() {
		try {
			dbManager = new DBManager("org.postgresql.Driver", "jdbc:postgresql://localhost:5432/clinic", "postgres", "niidea2004");
			this.initialize();
		}
		catch (Exception e) {
			System.out.println(e);
		}
	}
	
	private void initialize() throws SQLException {
		medicines = new HashMap<Integer, Medicine>();
		patients = new HashMap<Integer, Patient>();
		medicalAssurances = new HashMap<Integer, MedicalAssurance>();
		prescriptions = new ArrayList<Prescription>();

		//TODO: completar las colecciones de medicinas, pacientes, coberturas medicas y prescripciones con los datos recuperados desde la Base de Datos 
		String consulta = "SELECT medicalassurance, name FROM medicalassurance ";
		PreparedStatement stmt = this.dbManager.getConnection().prepareStatement(consulta);
		ResultSet rs = stmt.executeQuery();
		while(rs.next()) {
			Integer id = new Integer(rs.getInt("medicalassurance"));
			String name = rs.getString("name");
			medicalAssurances.put(id, new MedicalAssurance(id,name));
		}
		
		consulta = "SELECT medicine, description, unitprice FROM medicine ";
		stmt = this.dbManager.getConnection().prepareStatement(consulta);
		rs = stmt.executeQuery();
		while(rs.next()) {
			Integer id = new Integer(rs.getInt("medicine"));
			String name = rs.getString("description");
			BigDecimal price = new BigDecimal(rs.getDouble("unitprice"));
			medicines.put(id, new Medicine(id,name, price));
		}
		
		consulta = "SELECT patient, name, birthdate, medicalassurance FROM patient ";
		stmt = this.dbManager.getConnection().prepareStatement(consulta);
		rs = stmt.executeQuery();
		while(rs.next()) {
			Integer id = new Integer(rs.getInt("patient"));
			String name = rs.getString("name");
			Date birthDate = rs.getDate("birthdate");
			int medicalAssurance = rs.getInt("medicalassurance");
			patients.put(id, new Patient(id,name, birthDate, medicalAssurances.get(medicalAssurance)));
		}
		
		consulta = "SELECT prescription, date, professional, prescriptiontype, dailydose, days,  studyrequired, diagnosis, medicine, patient from prescription ";
		stmt = this.dbManager.getConnection().prepareStatement(consulta);
		rs = stmt.executeQuery();
		while(rs.next()) {
			Integer id = new Integer(rs.getInt("prescription"));
			Date date = rs.getDate("date");
			String pro = rs.getString("professional");
			String prescriptionType = rs.getString("prescriptiontype");
			if (prescriptionType.charAt(0) == 'M') {
				int dailyDose = rs.getInt("dailydose");
				int days = rs.getInt("days");
				Medicine medicine = medicines.get(rs.getInt("medicine"));
				Patient patient = patients.get(rs.getInt("patient"));
				prescriptions.add(new MedicinePrescription(id,patient,date, pro, dailyDose, days, medicine));
				
			}else if (prescriptionType.charAt(0) == 'S') {
				String study = rs.getString("studyrequired");
				String diagnosis = rs.getString("diagnosis");
				Patient patient = patients.get(rs.getInt("patient"));
				prescriptions.add(new StudyPrescription(id, patient, date, pro, study, diagnosis));
			}
			
		}
		
	}

	public String costsReports() {
		
		StringBuilder sb = new StringBuilder();
		Statement st;
		sb.append("=============================================================================================================================================");
		sb.append("\n");
		sb.append("Costo de Prescripciones");
		sb.append("\n");
		sb.append("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");		
		sb.append("\n");
		sb.append("Paciente" + "\t" + "Prescripcion" + "\t\t\t\t\t\t\t" + "Costo");
		sb.append("\n");
		sb.append("=============================================================================================================================================");
		sb.append("\n");
		
		//Hash sugerido para obtener el total por medico
		HashMap<String, Double> professionalsCosts = new HashMap<>();

		//TODO: Completar el reporte de los costos de prescripciones a partir de la lista de prescripciones
		
		Collections.sort(prescriptions);
		int control = -9;
		for(Prescription p : prescriptions) {
			if (professionalsCosts.containsKey(p.getProfessional()) ) {
				double price = professionalsCosts.get(p.getProfessional());
				price += p.getPrice();
				professionalsCosts.replace(p.getProfessional(), price);
			} else professionalsCosts.put(p.getProfessional(), new Double(p.getPrice()) );
			    
			
			if (p.getPatient().getPatient() != control) {
				sb.append("\n"+p.getPatient()+"\n");
				control = p.getPatient().getPatient(); 
			}
			sb.append(p);
			sb.append("\n");
			
		}
    	
		sb.append("\n\n");
    	sb.append("Totales por Medico\n\n");
		//TODO: Mostrar los Totales por cobertura medica
    	for ( HashMap.Entry<String, Double> entry : professionalsCosts.entrySet() )
        {
            sb.append(entry.getKey() +"\t $"+ entry.getValue()+"\n" );
        }
    	
		return sb.toString();
	}

}
