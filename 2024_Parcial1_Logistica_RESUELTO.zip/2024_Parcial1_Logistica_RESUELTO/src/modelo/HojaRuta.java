package modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public abstract class HojaRuta {

private static final double VALOR_POR_ENTREGA = 200;
private static final double VALOR_POR_KG = 10;
private static final double VALOR_POR_KM = 100;

private LocalDate fecha;
private float pesoTotal;
private float distanciaTotal;
private Movil movil;
private List<Entrega> entregas;

public HojaRuta(Movil movil) {
	super();
	this.fecha = LocalDate.now();
	this.pesoTotal = 0;
	this.distanciaTotal = 0;
	this.movil = movil;
	this.entregas = new ArrayList<>();
}

	public boolean agregar(Entrega entrega) {
		if (getPesoTotal() + entrega.getPeso() > getMovil().getCapacidadCarga())
			return false;
		pesoTotal += entrega.getPeso();
		distanciaTotal += entrega.getDistancia();
		return true;
	}

	public double getCosto() {
		return getEntregas().size() * VALOR_POR_ENTREGA 
				+ getPesoTotal() * VALOR_POR_KG
				+ 0.25 * getDistanciaTotal() * VALOR_POR_KM 
				+ getEntregas().getLast().getDistancia() * VALOR_POR_KM;

	}

	@Override
	public String toString() {
		return getMovil().getTipoMovil().name() + " - " + getFecha() + "_" + getMovil().getZona() + "_"
				+ getMovil().getTipoMovil().toString().charAt(0) + "  Capacidad:" + getMovil().getCapacidadCarga()
				+ "  Peso:" + getPesoTotal() + "  Km:" + getDistanciaTotal() + "  Costo: " + getCosto();
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public float getPesoTotal() {
		return pesoTotal;
	}

	public void setPesoTotal(float pesoTotal) {
		this.pesoTotal = pesoTotal;
	}

	public float getDistanciaTotal() {
		return distanciaTotal;
	}

	public void setDistanciaTotal(float distanciaTotal) {
		this.distanciaTotal = distanciaTotal;
	}

	public Movil getMovil() {
		return movil;
	}

	public void setMovil(Movil movil) {
		this.movil = movil;
	}

	public List<Entrega> getEntregas() {
		return entregas;
	}

	public void setEntregas(List<Entrega> entregas) {
		this.entregas = entregas;
	}

	public static double getValorPorEntrega() {
		return VALOR_POR_ENTREGA;
	}

	public static double getValorPorKg() {
		return VALOR_POR_KG;
	}

	public static double getValorPorKm() {
		return VALOR_POR_KM;
	}

	@Override
	public int hashCode() {
		return Objects.hash(distanciaTotal, entregas, fecha, movil, pesoTotal);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HojaRuta other = (HojaRuta) obj;
		return Float.floatToIntBits(distanciaTotal) == Float.floatToIntBits(other.distanciaTotal)
				&& Objects.equals(entregas, other.entregas) && Objects.equals(fecha, other.fecha)
				&& Objects.equals(movil, other.movil)
				&& Float.floatToIntBits(pesoTotal) == Float.floatToIntBits(other.pesoTotal);
	}

}
