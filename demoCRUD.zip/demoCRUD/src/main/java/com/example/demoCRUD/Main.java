package com.example.demoCRUD;

import DAO.PetDAO;
import DAO.PetTypeDAO;
import view.PetForm;
import view.PetTypeForm;

import javax.swing.*;
import java.awt.event.*;

public class Main {

    public Main() {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JFrame frame = new JFrame("Menú Principal");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                JMenuBar menuBar = new JMenuBar();
                JMenu formsMenu = new JMenu("Formularios");

                // Crear los items del menú
                JMenuItem petTypeFormMenuItem = new JMenuItem("Gestión de Tipos de Mascota");
                JMenuItem petFormMenuItem = new JMenuItem("Gestión de Mascotas");

                PetTypeDAO petTypeDAO = new PetTypeDAO();
                // Agregar ActionListener para abrir los formularios respectivos
                petTypeFormMenuItem.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        new PetTypeForm(petTypeDAO);
                    }
                });

                petFormMenuItem.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        PetDAO petDAO = new PetDAO();
                        new PetForm(petDAO, petTypeDAO);
                    }
                });

                // Agregar los items al menú
                formsMenu.add(petTypeFormMenuItem);
                formsMenu.add(petFormMenuItem);
                menuBar.add(formsMenu);

                // Agregar el menú al JFrame principal
                frame.setJMenuBar(menuBar);

                frame.setSize(400, 300);
                frame.setLocationRelativeTo(null); // Centrar ventana
                frame.setVisible(true);
            }
        });
    }
}
