package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

private static final String jdbcUrl  = "jdbc:postgresql://localhost:5432/oncedesunidos";
private static final String username = "postgres";
private static final String password = "niidea2004";	//mi usuario, sino seria 1234
private static final String driver = "org.postgresql.Driver";

	public static Connection getConnection() throws SQLException {
		//TO DO: devolver conexión a la base de datos, aquí
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return DriverManager.getConnection(jdbcUrl, username, password);
		
	}
}
