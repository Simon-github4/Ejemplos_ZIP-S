package model.prescriptions;

import java.util.Date;

import model.Medicine;
import model.Patient;

public class MedicinePrescription extends Prescription{

private int dailyDose;
private int days;
private Medicine medicine;
	
public MedicinePrescription(int prescription, Patient patient, Date date, String professional, int dailyDose, int days, Medicine medicine) {
		super(prescription, patient, date, professional);
		this.dailyDose= dailyDose;
		this.days= days;
		this.medicine=medicine;
		
	}

public int getDailyDose() {
	return dailyDose;
}

public void setDailyDose(int dailyDose) {
	this.dailyDose = dailyDose;
}

public int getDays() {
	return days;
}

public void setDays(int days) {
	this.days = days;
}

public Medicine getMedicine() {
	return medicine;
}

public void setMedicine(Medicine medicine) {
	this.medicine = medicine;
}

@Override
public String toString() {
	return getDate()+"-"+ getProfessional() +"\t"+ medicine +"\t"+"Dosis Diaria :"+ dailyDose+" Dias: "+ days+"\t"+getPrice();
}

@Override
public float getPrice() {
	// Cant. Dosis diaria * precio unitario * cantidad de días del tratamiento
	double dv = medicine.getUnitPrice().doubleValue();
	return (float) (dailyDose * dv * days);
}

}
