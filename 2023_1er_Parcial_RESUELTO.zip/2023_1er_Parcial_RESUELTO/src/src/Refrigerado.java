package src;

public class Refrigerado extends Compartimento{

	private static final double COSTO_KILOWATT_DIA = 10;
	private double temperatura;
	private double kilowatts;
	
	public Refrigerado(String idCompartimento, Area area, String descripcion
			, int capacidad, int cantOcupada, int temp, int kw) {
		super(idCompartimento, area, descripcion, capacidad, cantOcupada);
		this.temperatura = temp;
		this.kilowatts = kw;
	}

	public double getCosto() {
		double factTemp;
		if(getTemperatura() > 3)
			factTemp = 1;
		else if ((3 >= getTemperatura() ) && (getTemperatura() > -5))
				factTemp = 1.2;
		else factTemp = 1.5;// if(getTemperatura() <= -5)
		return super.getCosto() + COSTO_KILOWATT_DIA * kilowatts * factTemp;
	}
	
	@Override
	public String toString() {
		return super.toString() + "temperatra"+ temperatura +"   kw:"+kilowatts + "   Costo:"+getCosto() +"\n";
	}
	
	public double getTemperatura() {
		return temperatura;
	}

	public void setTemperatura(double temperatura) {
		this.temperatura = temperatura;
	}

	public double getKilowatts() {
		return kilowatts;
	}

	public void setKilowatts(double kilowatts) {
		this.kilowatts = kilowatts;
	}
	
	
}
