package model;

import java.math.BigDecimal;
import java.util.Objects;

public class Deporte {

private long iddeporte;
private String descripcion;
private BigDecimal valor;

public Deporte(long iddeporte, String descripcion, BigDecimal bigDecimal) {
	super();
	this.iddeporte = iddeporte;
	this.descripcion = descripcion;
	this.valor = bigDecimal;
}

public long getIdDeporte() {
	return iddeporte;
}

public void setIdDeporte(long iddeporte) {
	this.iddeporte = iddeporte;
}

public String getDescripcion() {
	return descripcion;
}

public void setDescripcion(String descripcion) {
	this.descripcion = descripcion;
}

public BigDecimal getValor() {
	return valor;
}

public void setValor(BigDecimal valor) {
	this.valor = valor;
}

@Override
public int hashCode() {
	return Objects.hash(descripcion, iddeporte, valor);
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Deporte other = (Deporte) obj;
	return Objects.equals(descripcion, other.descripcion) && iddeporte == other.iddeporte
			&& Objects.equals(valor, other.valor);
}

@Override
public String toString() {
	return  descripcion + "  ($ " + valor + ")\t";
}



	
}
