package src;

public class Compartimento {

private static final double COSTO_DIARIO_COMPARTIMENTO = 1000;
private static final double COSTO_DIARIO_NIVEL = 10;

private String idCompartimento;
private Area area;
private String descripcion;
private int capacidad;
private int cantOcupada;

public Compartimento(String idCompartimento, Area area, String descripcion, int capacidad, int cantOcupada) {
	this.idCompartimento = idCompartimento;
	this.area = area;
	this.descripcion = descripcion;
	this.capacidad = capacidad;
	this.cantOcupada = cantOcupada;
}

public boolean agregar(int cantidad) {
	if(getCantOcupada() + cantidad > getCapacidad())
		return false;
	else {
		setCantOcupada(getCantOcupada()+ cantidad);
		return true;
	}
		
}

public boolean retirar(int cantidad) {
	if(cantidad > getCantOcupada())
		return false;
	else {
		setCantOcupada(getCantOcupada() - cantidad);
		return true;
	}	
}

public double getCosto() {
	return COSTO_DIARIO_COMPARTIMENTO * getCantOcupada()/getCapacidad();
}


@Override
public String toString() {
	return " \t \t" + idCompartimento + " - " + descripcion + " ("+ this.getClass().getSimpleName() +")   Capacidad: " + capacidad + " \t Ocupado:" + cantOcupada+"\t";
}

public static double getCostoDiarioCompartimento() {
	return COSTO_DIARIO_COMPARTIMENTO;
}

public static double getCostoDiarioNivel() {
	return COSTO_DIARIO_NIVEL;
}

public String getIdCompartimento() {
	return idCompartimento;
}

public void setIdCompartimento(String idCompartimento) {
	this.idCompartimento = idCompartimento;
}

public Area getArea() {
	return area;
}

public void setArea(Area area) {
	this.area = area;
}

public String getDescripcion() {
	return descripcion;
}

public void setDescripcion(String descripcion) {
	this.descripcion = descripcion;
}

public int getCapacidad() {
	return capacidad;
}

public void setCapacidad(int capacidad) {
	this.capacidad = capacidad;
}

public int getCantOcupada() {
	return cantOcupada;
}

public void setCantOcupada(int cantOcupada) {
	this.cantOcupada = cantOcupada;
}


}
