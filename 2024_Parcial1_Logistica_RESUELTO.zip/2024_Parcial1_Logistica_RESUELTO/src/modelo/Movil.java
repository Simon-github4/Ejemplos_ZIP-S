package modelo;

import java.util.Objects;

public class Movil {

private String propietario;
private float capacidadCarga;
private Zonas zona;
private TipoMovil tipoMovil;

public Movil(String prop, TipoMovil tipoMovil, float capacidad, Zonas zona) {
	this.propietario = prop;
	this.tipoMovil = tipoMovil;
	this.capacidadCarga = capacidad;
	this.zona = zona;
}


public String getPropietario() {
	return propietario;
}

public void setPropietario(String propietario) {
	this.propietario = propietario;
}

public float getCapacidadCarga() {
	return capacidadCarga;
}

public void setCapacidadCarga(float capacidadCarga) {
	this.capacidadCarga = capacidadCarga;
}

public Zonas getZona() {
	return zona;
}

public void setZona(Zonas zona) {
	this.zona = zona;
}

public TipoMovil getTipoMovil() {
	return tipoMovil;
}

public void setTipoMovil(TipoMovil tipoMovil) {
	this.tipoMovil = tipoMovil;
}


@Override
public int hashCode() {
	return Objects.hash(capacidadCarga, propietario, tipoMovil, zona);
}


@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Movil other = (Movil) obj;
	return Float.floatToIntBits(capacidadCarga) == Float.floatToIntBits(other.capacidadCarga)
			&& Objects.equals(propietario, other.propietario) && tipoMovil == other.tipoMovil && zona == other.zona;
}

}
