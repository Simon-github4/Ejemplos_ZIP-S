package modelo;

import java.time.LocalDate;
import java.util.List;

public class hojaRutaRefrigerada extends HojaRutaCamion {

private static final double PORC_INCREMENTO = 1.40;
private float temperatura;

public hojaRutaRefrigerada(Movil movil) {
	super(movil);
	this.temperatura = 99;
}

	@Override
	public boolean agregar(Entrega entrega) {
		if (super.agregar(entrega) == false)
			return false;

		if (entrega.getTemperaturaRecomendada() < getTemperatura())
			setTemperatura(entrega.getTemperaturaRecomendada());

		return true;
	}

	@Override
	public double getCosto() {
		double costo = super.getCosto();
		return costo * PORC_INCREMENTO;
	}

	@Override
	public String toString() {
		return super.toString() + "\tC:" + temperatura;
	}

	public float getTemperatura() {
		return temperatura;
	}

	public void setTemperatura(float temperatura) {
		this.temperatura = temperatura;
	}

}
