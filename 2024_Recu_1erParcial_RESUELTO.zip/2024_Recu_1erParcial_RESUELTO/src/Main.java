import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import controller.Clinica;
import model.Bebe;
import model.Cirugia;
import model.Cirugia.TipoAnestesia;
import model.Medico;
import model.Parto;
import model.Quirofano;

public class Main {

    public static void main(String[] args) {
        Clinica clinica = new Clinica("Cura Tutti");
        clinica.add(new Medico("Dra. Mill", new BigDecimal(1000)));
        clinica.add(new Medico("Dr. Dosmi", new BigDecimal(2000)));
        clinica.add(new Medico("Dr.Tresmi", new BigDecimal(3000)));
        clinica.add(new Medico("Dr.Cuatro", new BigDecimal(4000)));
        clinica.add(new Medico("Dr.Cinque", new BigDecimal(5000)));
        clinica.add(new Medico("Dr.Seismi", new BigDecimal(6000)));
        clinica.add(new Medico("Dr.Sietem", new BigDecimal(7000)));
        clinica.add(new Medico("Dra Ochoa", new BigDecimal(8000)));

        clinica.add(new Quirofano(1, new BigDecimal(1000)));
        clinica.add(new Quirofano(2, new BigDecimal(2000)));
        clinica.add(new Quirofano(3, new BigDecimal(3000)));
        clinica.add(new Quirofano(4, new BigDecimal(4000)));
        
        clinica.add(new Cirugia("Luis", 61, false,clinica.getQuirofanoRandom(), clinica.getMedicosRandom(3), "Cardiaca", TipoAnestesia.LOCAL));

        Bebe bebe1 = new Bebe("Felipe", 1.7, 'H'); 
        Bebe bebe2 = new Bebe("Emilia", 1.2,'M'); 

        List<Bebe> bebes = new ArrayList<>();
        bebes.add(bebe1);
        bebes.add(bebe2);
        clinica.add(new Parto("Nahuel", 120, false, clinica.getQuirofanoRandom(), clinica.getMedicosRandom(3), false, bebes));
      
        bebes = new ArrayList<>();
        bebes.add(bebe1);
        clinica.add(new Parto("Maxi", 87, true, clinica.getQuirofanoRandom(), clinica.getMedicosRandom(5), true, bebes));
       
        clinica.add(new Cirugia("Carla", 189, true,clinica.getQuirofanoRandom(), clinica.getMedicosRandom(1), "Plastica", TipoAnestesia.GENERAL));

        System.out.println(clinica.listarIntervenciones());

    }
}