package controlador;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import modelo.Entrega;
import modelo.HojaRuta;
import modelo.HojaRutaBicicleta;
import modelo.HojaRutaCamion;
import modelo.Movil;
import modelo.TipoMovil;
import modelo.Zonas;
import modelo.hojaRutaRefrigerada;

public class Empresa {

private String nombre;
private List<Movil> moviles;
private List<Zonas> zonas; 
private List<Entrega> entregasPendientes;
private Map<String, HojaRuta> hojasDeRuta;

public Empresa(String nombre) {
	this.nombre = nombre;
	this.moviles = new ArrayList<>();
	this.zonas = new ArrayList<>();
	this.entregasPendientes = new ArrayList<>();
	this.hojasDeRuta = new HashMap<>();
}
	public void agregar(Movil movil) {
		// Agregar un Movil a la Empresa
		moviles.add(movil);
	}

	public void agregar(Entrega entrega) {
		// Agregar la entrega a una Hoja de Ruta
		TipoMovil tipo = getTipoMovil(entrega.getTemperaturaRecomendada(), entrega.getPeso());
		String hojaNombre = entrega.getFechaRecepcion().toString() + "_" + entrega.getZona().name() + "_" + tipo.toString().charAt(0);

		if (!hojasDeRuta.containsKey(hojaNombre)) {
			if (tipo.equals(TipoMovil.BICICLETA))
				hojasDeRuta.put(hojaNombre, new HojaRutaBicicleta(getMovil(tipo, entrega.getZona())));
			else if (tipo.equals(TipoMovil.CAMION))
				hojasDeRuta.put(hojaNombre, new HojaRutaCamion(getMovil(tipo, entrega.getZona())));
			else
				hojasDeRuta.put(hojaNombre, new hojaRutaRefrigerada(getMovil(tipo, entrega.getZona())));
		}

		if (!hojasDeRuta.get(hojaNombre).agregar(entrega))
			entregasPendientes.add(entrega);
	}

	private Movil getMovil(TipoMovil tipoMovil, Zonas zona) {
		// Dado un Tipo de Movil y una Zona dada, devuelve el movil de dicho tipo que tenga asignado la zona dada
		for (Movil movil : moviles) {
			if (movil.getTipoMovil().equals(tipoMovil) && movil.getZona().equals(zona))
				return movil;
		}
		return null;
	}

	public String listarHojasRuta() {
		// Listar información de las Hojas de Ruta
		/*for(Entry<String, HojaRuta> entry : hojasDeRuta.entrySet()){
			System.out.println(entry.getKey() );//+ entry.getValue()
		}*/
		
		StringBuilder x = new StringBuilder();
		hojasDeRuta.forEach((nom, hoja) -> x.append(hoja.toString()));
		x.append("\n Entregas pendientes:\n");
		entregasPendientes.forEach(a -> x.append(a.toString()));

		return x.toString();
	}

	public TipoMovil getTipoMovil(float temp, float peso) {
		if (temp < 10f)
			return TipoMovil.REFRIGERADO;
		else if (peso <= 3)
			return TipoMovil.BICICLETA;
		else
			return TipoMovil.CAMION;
	}

}
