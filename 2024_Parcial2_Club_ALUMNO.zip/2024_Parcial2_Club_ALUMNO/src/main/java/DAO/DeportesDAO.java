package DAO;

import model.Deporte;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DeportesDAO {

    public void insertarDeporte(String descripcion, BigDecimal valor) throws SQLException {
        //TO DO: Insertar nuevo deporte en la tabla deportes, aquí
    }

    public void actualizarDeporte(long iddeporte, String descripcion, BigDecimal valor) throws SQLException {
        //TO DO: Actualizar registro en la tabla deportes, aquí
    }

    public void borrarDeporte(long iddeporte) throws SQLException {
        //TO DO: Eliminar registro en la tabla deportes, aquí
    }

    public List<Deporte> getListaDeportes() throws SQLException {
        List<Deporte> listaDeportes = new ArrayList<>();

        //TO DO: Recuperar registros de la tabla deportes y crearlos en la lista, aquí

        return listaDeportes;
    }


}

