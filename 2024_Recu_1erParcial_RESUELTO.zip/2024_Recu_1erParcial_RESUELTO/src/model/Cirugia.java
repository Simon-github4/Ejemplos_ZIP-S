package model;

import java.util.List;

public class Cirugia extends Intervencion{

public enum TipoAnestesia{ LOCAL, GENERAL };

private static final double PORC_INCREMENTO_ANESTESIAGENERAL = 30;
private String descripcion;
private TipoAnestesia tipoAnestesia;

public Cirugia(String paciente, int duracion, boolean urgente, Quirofano quirofano, List<Medico> medicos, String descripcion, TipoAnestesia tipoA) {
	super(paciente, duracion, urgente, quirofano, medicos);
	this.descripcion = descripcion;
	this.tipoAnestesia = tipoA;
}



@Override
public String toString() {
	return super.toString() + " \tdescripcion: " + getDescripicon() + "  Anestesia: " + getTipoAnestesia() +"\n";
}

@Override
public double getFacturacion(){
	double valorBase = super.getFacturacion();
	if(getTipoAnestesia().equals(TipoAnestesia.GENERAL))
		valorBase += valorBase * (getPorcIncrementoAnestesiageneral()/100);
	
	return valorBase;
}

public static double getPorcIncrementoAnestesiageneral() {
	return PORC_INCREMENTO_ANESTESIAGENERAL;
}

public String getDescripicon() {
	return descripcion;
}
public void setDescripicon(String descripicon) {
	this.descripcion = descripicon;
}
public TipoAnestesia getTipoAnestesia() {
	return tipoAnestesia;
}
public void setTipoAnestesia(TipoAnestesia tipoAnestesia) {
	this.tipoAnestesia = tipoAnestesia;
}


}
