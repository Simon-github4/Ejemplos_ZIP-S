package src;

public class Aportante extends Colaborador {

public enum tipo {
	PADRINO, BENEFACTOR
};

private double aporteMensual;
private tipo tipoAportante;

	public Aportante(String nombre, int anioIngreso, double aporte) {
		super(nombre, anioIngreso);
		this.aporteMensual = aporte;
		if (aporte < 30000)
			tipoAportante = tipo.BENEFACTOR;
		else
			tipoAportante = tipo.PADRINO;
	}

	public double getAporteMensual() {
		return aporteMensual;
	}

	public void setAporteMensual(double aporteMensual) {
		this.aporteMensual = aporteMensual;
		if (aporteMensual < 30000)
			setTipoAportante(tipo.BENEFACTOR);
		else
			setTipoAportante(tipo.PADRINO);
	}

	public tipo getTipoAportante() {
		return tipoAportante;
	}

	public void setTipoAportante(tipo tipoAportante) {
		this.tipoAportante = tipoAportante;
	}

	@Override
	public String toString() {
		return super.toString()+" \t "+ getTipoAportante()+ " \t "+ aporteMensual +"\n";
	}

}
