package DAO;

import model.Socio;
import model.Deporte;
import model.SocioVitalicio;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SociosDAO {
    private DeportesDAO petTypeDAO = new DeportesDAO();

    public void insertarSocio(String nombre, char genero, boolean vitalicio, List<Deporte> listaDeportes) throws SQLException {
        String sql = "INSERT INTO socios (idsocio, nombre, genero, vitalicio) VALUES (nextval('socios_idsocio_seq'), ?, ?, ?) RETURNING idsocio";
        long idSocio = -1;
        try (Connection conn = DBConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, nombre);
            pstmt.setString(2, String.valueOf(genero));
            pstmt.setBoolean(3, vitalicio);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                idSocio = rs.getInt("idsocio");
                if (!listaDeportes.isEmpty()) {
                    sql = "INSERT INTO socios_deportes (idsocio, iddeporte) VALUES (?, ?)";
                    PreparedStatement pstmt2 = conn.prepareStatement(sql);
                    pstmt2 = conn.prepareStatement(sql);
                    for (Deporte deporte: listaDeportes) {
                        pstmt2.setLong(1, idSocio);
                        pstmt2.setLong(2, deporte.getIdDeporte());
                        pstmt2.executeUpdate();
                    }
                }
            }
        }
    }

    public void actualizarSocio(long idsocio, String nombre, char genero, boolean vitalicio, List<Deporte> listaDeportes) throws SQLException {
            //TO DO: Actualizar el registro del socio, aquí
    	String consulta = "UPDATE socios SET nombre = ?, genero = ?, vitalicio = ? WHERE idsocio = ?";
		Connection conexion = DBConnection.getConnection();
		PreparedStatement pstmt = conexion.prepareStatement(consulta);
		pstmt.setString(1, nombre);
		String aux = genero+"";
		pstmt.setString(2, aux);
		pstmt.setBoolean(3, vitalicio);
		pstmt.setLong(4, idsocio);
		pstmt.executeUpdate();
            //TO DO: Borrar los deportes que el socio tenía previamente registrados en la tabla socios_deportes (ver método eliminarDeportesSocio)
		eliminarDeportesSocio(idsocio);
            //TO DO: Insertar los nuevos deportes del socio en la tabla socios_deportes, aquí
		for(Deporte deporte : listaDeportes) {
			String sql = "INSERT INTO socios_deportes (idsocio, iddeporte) VALUES(?, ?)";
			Connection con = DBConnection.getConnection();
			PreparedStatement stmt = con.prepareStatement(sql);
	        stmt.setLong(1, idsocio);
	        stmt.setLong(2, deporte.getIdDeporte());
	        stmt.executeUpdate();
		}
    }

    public void eliminarSocio(long idsocio) throws SQLException {
        //TO DO: Borrar el registro del socio, aquí
		eliminarDeportesSocio(idsocio);
    	String consulta = "DELETE FROM socios WHERE idsocio = ? ";
    	Connection conn = DBConnection.getConnection();
    	PreparedStatement pstmt = conn.prepareStatement(consulta);
    	pstmt.setLong(1, idsocio);
    	pstmt.executeUpdate();
    	
    }

    public void eliminarDeportesSocio(long idsocio) throws SQLException {
        //TO DO: Borrar los registros de los deportes que practica el socio (tabla socios_deportes), aquí
    	String consulta = "DELETE FROM socios_deportes WHERE idsocio = ? ";
    	Connection conn = DBConnection.getConnection();
    	PreparedStatement pstmt = conn.prepareStatement(consulta);
    	pstmt.setLong(1, idsocio);
    	pstmt.executeUpdate();
    }

    public List<Socio> getListaSocios() throws SQLException {
        List<Socio> listaSocios = new ArrayList<Socio>();
        //TO DO: Recuperar registros de la tabla socios y crearlos en la lista, aquí
        //       De cada socio recuperar los deportes que practica invocando al método getDeportesSocio(idSocio)
        String consulta = "SELECT idsocio, nombre, genero, vitalicio FROM socios";
        try (Connection conn = DBConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(consulta)) {
        	ResultSet rs = pstmt.executeQuery();
        	while(rs.next()) {
        		Socio socio; //declara y luego crea los socios segun si es vitalicio o no
        		if (rs.getBoolean("vitalicio")) {
        			socio = new SocioVitalicio(rs.getLong("idsocio"),
        										rs.getString("nombre"),
        										  rs.getString("genero").charAt(0));
        		} else {
        			socio = new Socio(rs.getLong("idsocio"),
        										rs.getString("nombre"),
        										  rs.getString("genero").charAt(0));
        		}
        		List<Deporte> deportesXSocio = getDeportesSocio(socio.getIdSocio());//Almacena los deportes de cada socio en una lista
        		socio.setDeportes(deportesXSocio); // Asigna a cada socio en su atributo la lista con sus deportes
        		listaSocios.add(socio);
        	}	
         }
        
        return listaSocios;
    }

    public List<Deporte> getDeportesSocio(Long idSocio) throws SQLException {
        //Recupera los deportes que practica el Socio y los devuelve en una lista
        List<Deporte> listaDeportesSocio = new ArrayList<Deporte>();
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT d.iddeporte, d.descripcion, d.valor FROM socios_deportes AS sd ");
        sql.append(" JOIN deportes AS d ON d.iddeporte = sd.iddeporte ");
        sql.append(" WHERE sd.idsocio = ?");

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
            stmt.setLong(1, idSocio);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Deporte deporte = new Deporte(rs.getLong("iddeporte"),
                                               rs.getString("descripcion"),
                                                rs.getBigDecimal("valor"));
                listaDeportesSocio.add(deporte);
            }
        }
        return listaDeportesSocio;
    }

}
