package DAO;

import model.Pet;
import model.PetType;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PetDAO {
    private PetTypeDAO petTypeDAO = new PetTypeDAO();

    public void insertPet(String name, int yearofbirth, String notes, long pettypeId) throws SQLException {
        String sql = "INSERT INTO pet (pet, name, yearofbirth, notes, pettype) VALUES (nextval('pet_pet_seq'), ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, name);
            pstmt.setInt(2, yearofbirth);
            pstmt.setString(3, notes);
            pstmt.setLong(4, pettypeId);
            pstmt.executeUpdate();
        }
    }

    public void updatePet(long petId, String newName, int newYearofbirth, String newNotes, long newPettypeId) throws SQLException {
        String sql = "UPDATE pet SET name = ?, yearofbirth = ?, notes = ?, pettype = ? WHERE pet = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, newName);
            pstmt.setInt(2, newYearofbirth);
            pstmt.setString(3, newNotes);
            pstmt.setLong(4, newPettypeId);
            pstmt.setLong(5, petId);
            pstmt.executeUpdate();
        }
    }

    public void deletePet(long petId) throws SQLException {
        String sql = "DELETE FROM pet WHERE pet = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setLong(1, petId);
            pstmt.executeUpdate();
        }
    }
    public List<Pet> getAllPets() throws SQLException {
        String sql = "SELECT pet, name, yearofbirth, notes, pettype FROM pet";
        List<Pet> pets = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                long petId = rs.getLong("pet");
                String name = rs.getString("name");
                int yearofbirth = rs.getInt("yearofbirth");
                String notes = rs.getString("notes");
                long pettypeId = rs.getLong("pettype");

                PetType pettype = petTypeDAO.getPetTypeById(pettypeId); // Método para obtener PetType por ID
                Pet pet = new Pet(petId, name, yearofbirth, notes, pettype);
                pets.add(pet);
            }
        }

        return pets;
    }
    public void displayAllPets() throws SQLException {
        String sql = "SELECT pet, name, yearofbirth, notes, pettype FROM pet";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                long petId = rs.getLong("pet");
                String name = rs.getString("name");
                int yearofbirth = rs.getInt("yearofbirth");
                String notes = rs.getString("notes");
                long pettypeId = rs.getLong("pettype");
                System.out.println("Pet ID: " + petId + ", Name: " + name + ", Year of birth: " + yearofbirth +
                        ", Notes: " + notes + ", Pet Type ID: " + pettypeId);
            }
        }
    }
}
