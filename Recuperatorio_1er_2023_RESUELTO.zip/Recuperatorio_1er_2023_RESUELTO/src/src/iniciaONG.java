package src;

public class iniciaONG {

	public static void main(String[] args) {
		ONG ong = new ONG("La Solidaria");
		ong.agregar(new Colaboracion("difusion ong", 15000));
		ong.agregar(new Colaboracion("apoyo escolar", 5000));
		ong.agregar(new Colaboracion("preparacion de comidas", 10000));
		ong.agregar(new Colaboracion("tareas administrativas", 30000));
		
		Voluntario azu = new Voluntario("azul", 2019);
		azu.agregar(new Colaboracion("tareas administrativas", 30000));
		azu.agregar(new Colaboracion("apoyo escolar", 5000));
		azu.agregar(new Colaboracion("preparacion de comidas", 10000));
		ong.agregar(azu);
		
		Voluntario tomi = new Voluntario("tomas", 2018);
		tomi.agregar(new Colaboracion("difusion ong", 15000));
		tomi.agregar(new Colaboracion("preparacion de comidas", 10000));
		tomi.agregar(new Colaboracion("tareas administrativas", 30000));
		tomi.agregar(new Colaboracion("apoyo escolar", 5000));
		ong.agregar(tomi);
		
		ong.agregar(new Aportante("simon", 2020, 25000) );
		ong.agregar(new Aportante("mauricio", 2012, 45000) );
		ong.agregar(new Aportante("natalia", 2010, 30000) );

		System.out.println(ong.mostrarInfo());	
	}
}
