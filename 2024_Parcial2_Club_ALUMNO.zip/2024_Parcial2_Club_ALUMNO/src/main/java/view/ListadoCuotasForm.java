package view;

import model.Socio;
import java.awt.*;
import java.util.List;
import javax.swing.*;

public class ListadoCuotasForm extends JFrame {
    private
    JTextArea areaDeTexto;
    public ListadoCuotasForm(String titulo) {
        setTitle(titulo);
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setSize(400, 300);
        setLayout(new BorderLayout());

        // Crear el área de texto (JTextArea)
        areaDeTexto = new JTextArea(40, 150);
        areaDeTexto.setLineWrap(true);  // Habilitar salto de línea automático
        areaDeTexto.setWrapStyleWord(true);  // Saltar líneas en palabras completas
        areaDeTexto.setFont(new Font("Monospaced", Font.PLAIN, 12));

        // Envolver el JTextArea en un JScrollPane para hacerlo scrollable
        JScrollPane scrollPane = new JScrollPane(areaDeTexto);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        // Añadir el JScrollPane (con el JTextArea dentro) al formulario
        add(scrollPane, BorderLayout.CENTER);

        // Mostrar la ventana
        pack(); // Ajustar el tamaño de la ventana automáticamente
        setLocationRelativeTo(null); // Centrar ventana
        setVisible(true);
    }

    public void listarCuotas(List<Socio> listaSocios) {
        //TO DO: Listar Socios y sus cuotas, en el TextArea
    }

}
