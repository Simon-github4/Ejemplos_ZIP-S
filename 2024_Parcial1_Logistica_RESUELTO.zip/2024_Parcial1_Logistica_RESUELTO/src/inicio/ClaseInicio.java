package inicio;

import controlador.Empresa;
import modelo.Entrega;
import modelo.Movil;
import modelo.TipoMovil;
import modelo.Zonas;

public class ClaseInicio {
	
	public static void main(String[] args) {
		
		//1°) Crear la empresa
		Empresa empresa = new Empresa("TeLoLlevo S.A");
		
		//2°) Agregar los móviles a la empresa
/*		
 */		
 		empresa.agregar(new Movil("Diego", TipoMovil.BICICLETA, 8.5f, Zonas.ESTE));		
		empresa.agregar(new Movil("Pedro", TipoMovil.CAMION, 250.0f, Zonas.ESTE));	
		empresa.agregar(new Movil("Elena", TipoMovil.REFRIGERADO, 300.0f, Zonas.ESTE));
		empresa.agregar(new Movil("Pilar", TipoMovil.BICICLETA, 10.0f, Zonas.OESTE));
		empresa.agregar(new Movil("Pablo", TipoMovil.CAMION, 150.0f, Zonas.OESTE));		
		empresa.agregar(new Movil("Amira", TipoMovil.REFRIGERADO, 300.0f, Zonas.OESTE));
		empresa.agregar(new Movil("Osmar", TipoMovil.BICICLETA, 9.0f, Zonas.NORTE));
		empresa.agregar(new Movil("Irene", TipoMovil.CAMION, 280.0f, Zonas.NORTE));		
		empresa.agregar(new Movil("Maris", TipoMovil.REFRIGERADO, 350.0f, Zonas.NORTE));	
		empresa.agregar(new Movil("Clara", TipoMovil.BICICLETA, 9.0f, Zonas.SUR));
		empresa.agregar(new Movil("Mario", TipoMovil.CAMION, 220.0f, Zonas.SUR));		
		empresa.agregar(new Movil("Mayra", TipoMovil.REFRIGERADO, 280.0f, Zonas.SUR));
		//3°) Agregar entregas a Hojas de Ruta
/*
 */
		empresa.agregar(new Entrega("800", "Lopez", "Luro   4433", 1.0f, 30.0f, Zonas.OESTE));
		empresa.agregar(new Entrega("801", "Perez", "Manso  4500", 10.0f, 1.5f, Zonas.NORTE));
		empresa.agregar(new Entrega("802", "Rubio", "Luro   5544", 5.0f, 18.0f, Zonas.OESTE));
		empresa.agregar(new Entrega("803", "Lopez", "Luro   4433", 1.0f, 25.0f, Zonas.OESTE, 5.0f));
		empresa.agregar(new Entrega("804", "Jerez", "Edison 5025", 35.0f, 12.0f, Zonas.SUR));
		empresa.agregar(new Entrega("805", "Muniz", "Moreno 2233", 1.0f, 30.0f, Zonas.ESTE));
		empresa.agregar(new Entrega("806", "Ramal", "Alice  6677", 7.0f, 2.5f, Zonas.NORTE));
		empresa.agregar(new Entrega("807", "Lemos", "Rejon  7788", 11.5f, 3.5f, Zonas.NORTE));
		empresa.agregar(new Entrega("808", "Landi", "Garay  5432", 5.0f, 25.0f, Zonas.OESTE, -1.0f));
		empresa.agregar(new Entrega("809", "Remon", "Funes   155", 8.5f, 2.8f, Zonas.NORTE));		
		empresa.agregar(new Entrega("810", "Brady", "Jara    260", 9.5f, 3.0f, Zonas.NORTE));
		empresa.agregar(new Entrega("811", "Lucky", "Colon  6732", 25.0f, 110.0f, Zonas.OESTE, 8.0f));
		empresa.agregar(new Entrega("812", "Matta", "Irala  6044", 10.0f, 15.0f, Zonas.SUR));
		empresa.agregar(new Entrega("813", "Kruck", "Ayolas 5777", 12.0f, 11.0f, Zonas.SUR));
		empresa.agregar(new Entrega("814", "Reino", "Alsina 2888", 3.5f, 40.0f, Zonas.ESTE));
		empresa.agregar(new Entrega("815", "Muniz", "Alsina 3000", 3.55f, 100.0f, Zonas.ESTE));
		empresa.agregar(new Entrega("816", "Muniz", "Alsina 3000", 3.55f, 150.0f, Zonas.ESTE));
		empresa.agregar(new Entrega("817", "Muniz", "Alsina 3000", 3.55f, 80.0f, Zonas.ESTE));
		empresa.agregar(new Entrega("818", "Russo", "Strobel 667", 7.0f, 2.5f, Zonas.NORTE));
		
		//4°) Listar Hojas de Ruta
		System.out.println(empresa.listarHojasRuta());
	}
}
