package modelo;

import java.time.LocalDate;
import java.util.List;

public class HojaRutaBicicleta extends HojaRuta {

	

	public HojaRutaBicicleta(Movil movil) {
		super(movil);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean agregar(Entrega entrega) {
		boolean rta = super.agregar(entrega);
		if (getEntregas().size() == 3)
			rta = false;
		else {
			getEntregas().add(entrega);	
			rta = true;
		}
		return rta;
	}
	
	

	@Override
	public double getCosto() {
		double costo = super.getCosto();
		return costo - super.getPesoTotal()*getValorPorKg();
	}

	@Override
	public String toString() {
		return super.toString() +"\n"+ getEntregas()+"\n" ;
	}

}
