package model;

import java.util.List;

public class Parto extends Intervencion{

private static final double ADICIONAL_CESAREA_PARTOMULTIPLE = 1000;

private boolean cesarea;
private List<Bebe>bebes;

public Parto(String paciente, int duracion, boolean urgente, Quirofano quirofano, List<Medico> medicos, boolean cesarea, List<Bebe> bebes) {
	super(paciente, duracion, urgente, quirofano, medicos);
	this.cesarea = cesarea;
	this.bebes = bebes;
}

@Override
public double getFacturacion(){
	double valorBase = super.getFacturacion();
	if(bebes.size() > 1 || cesarea == true)
		valorBase += getAdicionalCesareaPartomultiple();
	return valorBase;
}

@Override
public String toString() {
	StringBuilder sb = new StringBuilder();
	getBebes().forEach((a->sb.append(a.toString() + "   -")));
	return super.toString() + " \tCesarea: " + (isCesarea()?"Si  ":"No  ") + sb.toString() +"\n"; 
}

public static double getAdicionalCesareaPartomultiple() {
	return ADICIONAL_CESAREA_PARTOMULTIPLE;
}

public boolean isCesarea() {
	return cesarea;
}
public void setCesarea(boolean cesarea) {
	this.cesarea = cesarea;
}
public List<Bebe> getBebes() {
	return bebes;
}
public void setBebes(List<Bebe> bebes) {
	this.bebes = bebes;
}




}
