package com.example.demoCRUD;

import jakarta.annotation.PostConstruct;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoCrudApplication.class, args);
	}

	@PostConstruct
	private void runMethod() {
		System.setProperty("java.awt.headless", "false");
		Main main = new Main();
	}

}
