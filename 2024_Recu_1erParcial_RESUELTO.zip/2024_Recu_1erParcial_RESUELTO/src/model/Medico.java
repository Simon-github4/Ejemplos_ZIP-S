package model;

import java.math.BigDecimal;
import java.util.Objects;

public class Medico {
    private String nombre;
    private BigDecimal valorHora;

    public Medico(String nombre, BigDecimal valorHora) {
        this.nombre = nombre;
        this.valorHora = valorHora;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public BigDecimal getValorHora() {
        return valorHora;
    }

    public void setValorHora(BigDecimal valorHora) {
        this.valorHora = valorHora;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Medico medico = (Medico) o;
        return Objects.equals(nombre, medico.nombre) && Objects.equals(valorHora, medico.valorHora);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, valorHora);
    }
    public String toString() {
        return nombre;
    }
}
